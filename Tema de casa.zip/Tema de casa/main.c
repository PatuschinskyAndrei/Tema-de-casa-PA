#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NUM_ANGAJATI 3
#define NUM_SETS 10

// Structura pentru o carte
typedef struct {
    int numar_pagini;
} Carte;

// Functie pentru generarea de numere aleatoare
int generare_numar_aleator(int min, int max) {
    return min + rand() % (max - min + 1);
}

// Functie pentru calcularea sumei paginilor dintr-un vector de carti
int suma_pagini(Carte *carti, int numar_carti) {
    int suma = 0;
    for (int i = 0; i < numar_carti; i++) {
        suma += carti[i].numar_pagini;
    }
    return suma;
}

// Functie de comparare pentru qsort
int compara_pagini(const void *a, const void *b) {
    Carte *carteA = (Carte *)a;
    Carte *carteB = (Carte *)b;
    return carteB->numar_pagini - carteA->numar_pagini; // sortare descrescatoare
}

// Functie pentru impartirea echilibrata a cartilor intre angajati
void imparte_cartile(Carte *carti, int numar_carti, int *pagini_angajati) {
    // Sortam cartile in functie de numarul de pagini in ordine descrescatoare
    qsort(carti, numar_carti, sizeof(Carte), compara_pagini);

    // Alocarea sarcinilor pentru fiecare angajat
    int pagini[NUM_ANGAJATI] = {0}; // Paginile asignate fiecarui angajat

    // Iteram prin carti si le alocam angajatilor
    for (int i = 0; i < numar_carti; i++) {
        int min_index = 0;
        for (int j = 1; j < NUM_ANGAJATI; j++) {
            if (pagini[j] < pagini[min_index]) {
                min_index = j;
            }
        }
        pagini[min_index] += carti[i].numar_pagini;
    }

    // Copiem rezultatul in vectorul pagini_angajati
    for (int i = 0; i < NUM_ANGAJATI; i++) {
        pagini_angajati[i] = pagini[i];
    }
}

int main() {
    srand(time(NULL)); // Inițializare seed pentru funcția rand()

    for (int set = 0; set < NUM_SETS; set++) {
        printf("Setul %d:\n", set + 1);
        // Generare un numar random de carti
        int numar_carti = generare_numar_aleator(5, 15); // Numar mic de carti pentru variatie
        printf("Numarul de carti: %d\n", numar_carti);

        // Alocare de memorie pentru vectorul de carti
        Carte *carti = (Carte *)malloc(numar_carti * sizeof(Carte));

        // Generare pentru fiecare carte a unui numar random de pagini mare (peste 1000)
        printf("Numarul de pagini pentru fiecare carte:\n");
        for (int i = 0; i < numar_carti; i++) {
            carti[i].numar_pagini = generare_numar_aleator(1000, 2000); // Numar mare de pagini între 1000 și 2000
            printf("Carte %d: %d pagini\n", i + 1, carti[i].numar_pagini);
        }
        printf("\n");

        // Alocare pagini pentru fiecare angajat
        int pagini_angajati[NUM_ANGAJATI] = {0};
        imparte_cartile(carti, numar_carti, pagini_angajati);

        // Afisam sarcina fiecarui angajat
        printf("Sarcina fiecarui angajat:\n");
        for (int i = 0; i < NUM_ANGAJATI; i++) {
            printf("Angajat %d: %d pagini\n", i + 1, pagini_angajati[i]);
        }
        printf("\n");

        // Eliberare memorie alocata pentru vectorul de carti
        free(carti);
    }

    return 0;
}
